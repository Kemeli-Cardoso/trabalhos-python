valor1=int(input("Digite o valor 1: "))
valor2=int(input("Digite o valor 2: "))
if valor1== valor2:
    print("Numeros iguais.")
elif valor1>valor2:
    print(f"O valor maior é o {valor1}")
elif valor2>valor1:
    print(f"O valor maior é o {valor2}")
