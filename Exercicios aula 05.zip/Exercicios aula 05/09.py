valor1=float(input("Digite o valor 1: "))
valor2=float(input("Digite o valor 2: "))
valor3=float(input("Digite o valor 3: "))
valor_maior=valor1
if valor2>valor_maior:
    valor_maior=valor2
if valor3>valor_maior:
    valor_maior=valor3
print (valor_maior)
