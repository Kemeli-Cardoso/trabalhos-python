num1=float(input("Digite o valor 1: "))
num2=float(input("Digite o valor 2: "))
if num1>num2:
    print (f"A soma é {num1+num2}")
else:
    print (f"A subtração é {num1-num2}")