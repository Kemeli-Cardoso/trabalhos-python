valor1= int(input("Digite o valor 1: "))
valor2= int(input("Digite o valor 2: "))
if valor1>valor2:
    print (f"Somando 100 ao maior valor obtemos o número {valor1+100}")
else:
    print(f"Somando 100 ao maior valor obtemos o número {valor2+100}")