saldo=float(input("Digite o saldo da conta: "))
if saldo<0:
    print ("Conta estourada.")
else:
    print ("Conta regular.")