valor1=int(input("Digite o valor 1: "))
valor2=int(input("Digite o valor 2: "))
if valor1%2==0:
    print ("O valor 1 é multilho de 2.")
else:
    print ("O valor 1 não é multilho de 2.")
if valor2%2==0:
    print ("O valor 2 é multilho de 2")
else:
    print ("O valor 2 não é multilho de 2.")