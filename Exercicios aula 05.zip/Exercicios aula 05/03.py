valor1=int(input("Digite o valor 1: "))
valor2=int(input("Digite o valor 2: "))
if valor1>valor2:
    print(f"A diferença do maior pelo menor é de {valor1-valor2}")
else :
    print(f"A diferença do maior pelo menor é de {valor2-valor1}")
