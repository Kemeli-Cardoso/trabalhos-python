numero= float(input("Digite um número: "))
resto= numero%2
if resto==0:
    print ("O número é par.")
else:
    print ("O número é impar.")
if numero<0:
    print("O número é negativo.")
else:
    print("O número é positivo.")